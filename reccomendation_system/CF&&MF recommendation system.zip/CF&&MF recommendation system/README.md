# 协同过滤/隐语义模型示例
Collaborative Filtering / Matrix factorization demo

依赖的安装包:

- install 
- numpy 
- pandas 
- matplotlib 
- ipython-notebook
